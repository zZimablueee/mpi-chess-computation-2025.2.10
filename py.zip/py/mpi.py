from mpi4py import MPI
from stockfish import Stockfish
import chess
import chess.pgn
import os
import csv
from datetime import datetime

# ！！！这里改成你的 Stockfish 路径！！！
stockfish_path = "C:/Users/Administrator/Desktop/stockfish-windows-x86-64-avx2/stockfish/stockfish-windows-x86-64-avx2.exe"
stockfish = Stockfish(stockfish_path)

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

# ！！！这里改成你的 PGN 文件路径！！！
pgn_file_path = "C:\Users\Administrator\Desktop\MPI\33.pgn"

if rank == 0:
    with open(pgn_file_path, "r") as pgn_file:
        games = []
        while True:
            game = chess.pgn.read_game(pgn_file)
            if game is None:
                break
            games.append(game)
else:
    games = None

# 广播数据给所有进程
games = comm.bcast(games, root=0)

num_games = len(games)
games_per_process = num_games // size
start_idx = rank * games_per_process
end_idx = (rank + 1) * games_per_process if rank != size - 1 else num_games

local_games_detail = []
for i in range(start_idx, end_idx):
    game = games[i]
    board = chess.Board()
    move_scores = []
    Moves = []

    for move in game.mainline_moves():
        board.push(move)
        stockfish.set_fen_position(board.fen())
        evaluation = stockfish.get_evaluation()

        if evaluation["type"] == "cp":
            score = evaluation["value"]
        elif evaluation["type"] == "mate":
            score = evaluation["value"]

        move_scores.append(score / 500)
        Moves.append(move.uci())

    out_dict = {
        "Evaluation": move_scores,
        "Black": game.headers["Black"],
        "White": game.headers["White"],
        "Date": game.headers["Date"],
        "Competition": game.headers["Result"],
        "Round": game.headers["Round"],
        "Moves": Moves,
    }
    local_games_detail.append(out_dict)

# 收集所有进程的数据
all_games_detail = comm.gather(local_games_detail, root=0)

# ！！！这里改成你想要保存的 CSV 文件路径！！！
csv_file_path = "C:\Users\Administrator\Desktop\MPI\33.csv"

if rank == 0:
    keys = all_games_detail[0][0].keys()
    with open(csv_file_path, "a", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=keys)
        for game_detail in all_games_detail:
            for row in game_detail:
                writer.writerow(row)

current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"Rank {rank}: Data has been saved to '33.csv'")
print(f"Current timestamp: {current_time}")
