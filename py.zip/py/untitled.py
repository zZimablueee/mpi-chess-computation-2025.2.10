from mpi4py import MPI
from stockfish import Stockfish
import chess
import chess.pgn
from datetime import datetime
stockfish=Stockfish('C:/Users/Administrator/Desktop/stockfish-windows-x86-64-avx2/stockfish/stockfish-windows-x86-64-avx2.exe')

comm=MPI.COMM_WORLD
rank=comm.Get_rank()
size=comm.Get_size()

import os
pgn_file_path = 'C:\\Users\\Administrator\\Desktop\\MPI\\99.pgn'
if os.path.exists(pgn_file_path):
    print("File exists!")
else:
    print("File not found.")


if rank == 0:
    with open('C:\\Users\\Administrator\\Desktop\\MPI\\99.pgn', 'r') as pgn_file:
        games = []
        while True:
            game = chess.pgn.read_game(pgn_file)
            if game is None:
                break
            games.append(game)
else:
    games = None


games=comm.bcast(games,root=0)
print(f"Rank {rank}: Number of games received: {len(games)}")

num_games=len(games)
games_per_process=num_games//size
start_idx=rank*games_per_process
end_idx = (rank + 1) * games_per_process if rank != size - 1 else num_games
local_games_detail = []  # 用于存储当前进程处理的棋局的评估结果
for i in range(start_idx, end_idx):
    game = games[i]
    board = chess.Board()  # 初始化一个空棋盘
    move_scores = []  # 用于存储每步棋的评分
    Moves = []  # 用于存储每步棋的 UCI 格式表示
    
    for move in game.mainline_moves():
        board.push(move)  # 推进棋局，执行一棋步
        stockfish.set_fen_position(board.fen())  # 将棋盘转换为 FEN 格式，并传给 Stockfish 引擎
        evaluation = stockfish.get_evaluation()  # 获取评估结果
        
        if evaluation['type'] == 'cp':
            score = evaluation['value']
        elif evaluation['type'] == 'mate':
            score = evaluation['value']
        
        move_scores.append(score / 500)  # 将评分归一化（假设评分范围较大，归一化有助于统一尺度）
        Moves.append(move.uci())  # 将棋步转换为 UCI 格式

# 将当前棋局的评估信息整理为字典
    out_dict = {
        "Evaluation": move_scores,
        "Black": game.headers['Black'],
        "White": game.headers['White'],
        "Date": game.headers['Date'],
        "Competition": game.headers['Result'],
        "Round": game.headers['Round'],
        "Moves": Moves
    }
    
    local_games_detail.append(out_dict)  # 将当前棋局的评估信息添加到列表中


# In[123]:

import os
import csv

keys = local_games_detail[0].keys()  # 提取字典的 key 作为 CSV 表头


with open('99.csv', 'a', newline='', encoding='utf-8') as file:  # 追加模式 'a'
    writer = csv.DictWriter(file, fieldnames=keys)

    for row in local_games_detail:
        writer.writerow(row)

print(f"Rank {rank}: Data has been saved to '99.csv'")



# In[ ]:


current_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"Current timestamp: {current_time}")
