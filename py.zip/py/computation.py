#!/usr/bin/env python
# coding: utf-8

# In[2]:




# In[3]:


import chess.pgn


# # I have downloaded 10 pgn files from the webseite and they include 246 games

# In[45]:


pgn_files=['11.pgn','22.pgn','33.pgn','44.pgn','55.pgn','66.pgn','77.pgn','88.pgn','99.pgn','1010.pgn']
game_counts=[]
sum=0
for i,filename in enumerate(pgn_files,start=1):
    game_count=0
    with open(filename,'r') as pgn_file:
        while True:
            game=chess.pgn.read_game(pgn_file)
            if game is None:
                break
            game_count+=1
    game_counts.append(game_count)
    print(f"number of games in {filename}: {game_count}")
game_counts


# In[41]:


sum=0
for i in range(10):
    sum=sum+game_counts[i]
print(f'the total number of games:{sum}')


# # First i want to create the database of the first file(11.pgn) and after that i will do the same to the other 9 files.

# In[48]:


pgn=open('11.pgn')
first_game=chess.pgn.read_game(pgn)
print(first_game.headers)
for move in first_game.mainline_moves():
    print(move)


# In[53]:


from stockfish import Stockfish
import chess
stockfish=Stockfish('C:/Users/Administrator/Desktop/stockfish-windows-x86-64-avx2/stockfish/stockfish-windows-x86-64-avx2.exe')


# # Analyze the first game in the 11.pgn file to see if i can get the graph

# In[79]:


# # use a for loop to calculate all the 25 games in 11.pgn: 

# In[127]:


#循环求11.pgn里的其他场比赛
from stockfish import Stockfish
import chess
import chess.pgn
stockfish = Stockfish('C:/Users/Administrator/Desktop/stockfish-windows-x86-64-avx2/stockfish/stockfish-windows-x86-64-avx2.exe')
stockfish.set_depth(20)

games_detail=[]
pgn_file='11.pgn'
with open(pgn_file) as pgn:
    for i in range(25):
        board=chess.Board()
        move_scores=[]
        Moves=[]

        game=chess.pgn.read_game(pgn)
        if game is None:
            break
        for move in game.mainline_moves():
            board.push(move)
            stockfish.set_fen_position(board.fen())
            evaluation=stockfish.get_evaluation()

            if evaluation['type']=='cp':
                score=evaluation['value']
            elif evaluation['type']=='mate':
                score=evaluation['value']
            move_scores.append(score/500)
            Moves.append(move.uci())

        out_dict = {}
        out_dict["Evaluation"] = move_scores
        out_dict["Black"] = game.headers['Black']
        out_dict['White'] = game.headers['White']
        out_dict['Date'] = game.headers['Date']
        out_dict['Competition'] = game.headers['Result']
        out_dict['Round'] = game.headers['Round']
        out_dict['Moves'] = Moves
        games_detail.append(out_dict)

print(games_detail)


# In[129]:


import csv

# 假设 games_detail 已经存在，并且是一个列表，列表中的每个元素都是一个字典
keys=games_detail[0].keys()  # 提取 games_detail 的第一个元素（即 11.pgn 中第一场比赛）的 key 名称

# 确保输出文件名是 .csv 
with open('1.csv', 'w', newline='', encoding='utf-8') as file:
    writer=csv.DictWriter(file, fieldnames=keys)
    
    
    writer.writeheader()
    
    
    for row in games_detail:
        writer.writerow(row)
    
print("Data has been saved to '1.csv'")


# In[130]:


from datetime import datetime


current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"Current timestamp: {current_time}")


# # it shows that calculate all the games in 11.pgn file(25 games) without using MPI costs about 20mins

# # Try to calculate all the games in 11.pgn file using MPI:

# In[ ]:


from datetime import datetime

# 获取当前日期和时间并格式化
current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"Current timestamp: {current_time}")


# In[121]:


#对11.pgn加快运算速度
get_ipython().system('pip install mpi4py')
from mpi4py import MPI

comm=MPI.COMM_WORLD
rank=comm.Get_rank()
size=comm.Get_size()
if rank == 0:
    with open('11.pgn', 'r') as pgn_file:
        games = []
        while True:
            game = chess.pgn.read_game(pgn_file)
            if game is None:
                break
            games.append(game)
else:
    games = None

games=comm.bcast(games,root=0)

num_games=len(games)
games_per_process=num_games//size
start_idx=rank*games_per_process
end_idx = (rank + 1) * games_per_process if rank != size - 1 else num_games
local_games_detail = []  # 用于存储当前进程处理的棋局的评估结果
for i in range(start_idx, end_idx):
    game = games[i]
    board = chess.Board()  # 初始化一个空棋盘
    move_scores = []  # 用于存储每步棋的评分
    Moves = []  # 用于存储每步棋的 UCI 格式表示
    
    for move in game.mainline_moves():
        board.push(move)  # 推进棋局，执行一棋步
        stockfish.set_fen_position(board.fen())  # 将棋盘转换为 FEN 格式，并传给 Stockfish 引擎
        evaluation = stockfish.get_evaluation()  # 获取评估结果
        
        if evaluation['type'] == 'cp':
            score = evaluation['value']
        elif evaluation['type'] == 'mate':
            score = evaluation['value']
        
        move_scores.append(score / 500)  # 将评分归一化（假设评分范围较大，归一化有助于统一尺度）
        Moves.append(move.uci())  # 将棋步转换为 UCI 格式

# 将当前棋局的评估信息整理为字典
    out_dict = {
        "Evaluation": move_scores,
        "Black": game.headers['Black'],
        "White": game.headers['White'],
        "Date": game.headers['Date'],
        "Competition": game.headers['Result'],
        "Round": game.headers['Round'],
        "Moves": Moves
    }
    
    local_games_detail.append(out_dict)  # 将当前棋局的评估信息添加到列表中


# In[123]:


import csv

# 假设 games_detail 已经存在，并且是一个列表，列表中的每个元素都是一个字典
keys = local_games_detail[0].keys()  # 提取 games_detail 的第一个元素（即 11.pgn 中第一场比赛）的 key 名称

# 确保输出文件名是 .csv 格式
with open('11.csv', 'w', newline='', encoding='utf-8') as file:
    writer=csv.DictWriter(file, fieldnames=keys)
    
    writer.writeheader()

    for row in games_detail:
        writer.writerow(row)
    
print("Data has been saved to '11.csv'")


# In[ ]:


current_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"Current timestamp: {current_time}")


# # After using MPI , the time spent didn't decrease significantlly (still about 20 mins for 25 games)

# # and i also try to use the same MPI code for other files (each have  3、4、6、9 games) but the time also didnt decrease significantly compared to the original-for-loop-calculation code

# In[ ]:




